No photos; training only.
